#include <stdio.h>
#include <stdlib.h>
//Se la lista non e' ordinata la complessita' e' O(n*m).
//Converrebbe utilizzare un algoritmo di ordinamento.
int intersect(int *a, int n, int *b, int m){
   int i, j, res = 0;
   for(i=0; i<n; i++){
      for(j=0; j<m; j++){
         if(*(a+i)==*(b+j))res++;
      }

   }
   return res;
}

int main(){
   int *x, *y, lenx, leny, i, res;
   scanf("%d", &lenx);
   x = malloc(sizeof(int)*(lenx));
   for(i=0; i<lenx; i++){
      scanf("%d", x+i);
   }

   scanf("%d", &leny);
   y = malloc(sizeof(int)*(leny));
   for(i=0; i<leny; i++){
      scanf("%d", y+i);
   }

   res = intersect(x, lenx, y, leny);
   printf("%d\n", res);

   return 0;
}
