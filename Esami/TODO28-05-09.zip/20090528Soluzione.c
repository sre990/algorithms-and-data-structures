#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#define MAXLEN 256

typedef struct {
   char *stringa;
   int freq;
} entry; 

char **leggi(int *n, int *k)
{
  char **tutte;
  int i;

  scanf("%d%d", n, k); 

  assert ( *n > *k );
   
  tutte = (char **)malloc(sizeof(char *)* (*n));

  for ( i = 0; i < *n; i++ ) 
  {
     tutte[i]= (char *)malloc(sizeof(char)*(MAXLEN+1));
     scanf("%s", tutte[i]);
  }

  return tutte;
}

int 
cmpAlfa (const void *p1, const void *p2)
{
    return strcmp( *(char **)p1, *(char **)p2 );
}

int
cmpEntryAlfa(const void *p1, const void *p2)
{
    return strcmp( ((entry *)p1)->stringa, ((entry *)p2)->stringa );
}

int 
cmpEntryFreq(const void *p1, const void *p2)
{
   return ((entry *)p2)->freq - ((entry *)p1)->freq;
}

int main()
{
  int n, k, i, j;
  char **stringhe;
  entry *aggregate;
  
  stringhe = leggi(&n, &k); 

  aggregate = (entry *)malloc(sizeof(entry)*n);
 
  qsort ( stringhe, n, sizeof(char *), cmpAlfa);

  j = -1; 
  for ( i = 0; i < n; i++ ) 
     if ( j >= 0 && !strcmp(aggregate[j].stringa, stringhe[i] ) )
           aggregate[j].freq++;
     else
     {
           j++;
           aggregate[j].stringa = stringhe[i];
           aggregate[j].freq = 1;
     }
  

  qsort ( aggregate, j+1, sizeof(entry), cmpEntryFreq );

  qsort ( aggregate, k, sizeof(entry), cmpEntryAlfa );

  for ( i = 0; i < k; i++ ) 
    printf("%s\n", aggregate[i].stringa);

  return 0;
}
