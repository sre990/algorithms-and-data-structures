#include <stdio.h>
#include <stdlib.h>
//Assume che l'array sia gia' ordinato. E' O(n)
int intersect(int *a, int alen, int *b, int blen){
   int i, j, res;
   i=0, j=0, res=0;
   while(i<alen || j<blen){
      if(a[i]<b[j]) i++;
      if(b[j]<a[i]) j++;
      if(a[i]==b[j]) res++, i++, j++;
  }   
   return res;
}
int main(){
   int *x, *y, lenx, leny, i, res;
   scanf("%d", &lenx);
   x = malloc(lenx*sizeof(int));
   for(i=0; i<lenx; i++){
      scanf("%d", &x[i]);
   }

   scanf("%d", &leny);
   y = malloc(leny*sizeof(int));
   for(i=0; i<leny; i++){
      scanf("%d", &y[i]);
   }

   res = intersect(x, lenx, y, leny);
   printf("%d\n", res);

   return 0;
}
