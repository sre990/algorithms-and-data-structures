/* Soluzione appello Algoritmica 10/06/2009. */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>


/* Definizione di una lista di interi. */
typedef struct _lista {
    int dato;
    struct _lista *succ;
} lista;

/* Aggiunge in cima a "base" il valore "valore"
 * e restituisce la nuova testa della lista. */
lista *aggiungi(lista *base, int valore )
{
    lista *nodo = (lista *)malloc(sizeof(lista));

    nodo->dato = valore; 
    nodo->succ = base;

    return nodo;
}

/* Controlla se l'elemento "valore" esiste
 * nella lista "B" e restituisce 1, altrimenti 0.
 *
 * Per farlo, scorre tutta la lista fermandosi
 * in fondo o appena trova il valore.
 */
int cerca( lista *B, int valore )
{
    lista *currB = B;

    while ( currB != NULL && currB->dato != valore ) 
	currB = currB->succ;

    return (currB != NULL );
}

/* Cerca il minimo tra due liste A e B.o
 *
 * Per farlo, scorre la lista A e cerca ogni elemento
 * di A in B. Se l'elemento esiste aggiorna il minimo.
 * Attenzione che non potendo fare assunzioni sulla grandezza
 * del minimo, ma solo sulla sua positivita', bisogna
 * usare il caso speciale "min = -1".
 */

int
cercaminimo(lista *A, lista *B)
{
    int min = -1;
    lista *currA = A;

    while ( currA != NULL ) 
    {
       if ( cerca(B, currA->dato) && 
            (min == -1 || currA->dato < min) )
	 min = currA->dato;

       currA = currA->succ;
   }

   return min;
}


/* Main: legge le liste e chiama cercaminimo. */
int
main(int argc, char **argv)
{
   int na,  nb, i, valore;
   lista *A = NULL, *B = NULL;

   scanf("%d%d", &na, &nb);
   assert ( na > 0 );
   assert ( nb > 0 );
   for (i = 0; i < na; i++ ) 
   {
      scanf("%d", &valore);
      assert(valore >= 0);
      A = aggiungi(A, valore);
   } 
   for ( i = 0; i < nb; i++ ) 
   {
      scanf("%d", &valore);
      assert(valore >= 0);
      B = aggiungi(B, valore);
   }

   printf("%d\n", cercaminimo(A,B) );

   return 0; 
  
}
